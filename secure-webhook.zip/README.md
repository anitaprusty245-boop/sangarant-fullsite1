# Secure Webhook for Telegram Leads

Этот мини-сервер принимает POST-заявки и пересылает их в Telegram.

## 🚀 Деплой на Vercel или Netlify

### Vercel
1. Залейте папку `secure-webhook` в свой проект.
2. В настройках окружения добавьте переменные:
   - `BOT_TOKEN`
   - `CHAT_ID`
3. Готовый эндпоинт будет доступен по адресу:
   `https://your-domain.vercel.app/api/lead`

### Netlify
1. Разместите файлы, как есть.
2. В Netlify → Site settings → Environment добавьте:
   - `BOT_TOKEN`
   - `CHAT_ID`
3. Эндпоинт: `https://your-site.netlify.app/.netlify/functions/lead`

## 🧩 Проверка
Можно отправить тест:
```bash
curl -X POST https://your-domain.vercel.app/api/lead -H "Content-Type: application/json" -d '{"name":"Test","phone":"+7..."}'
```
