// netlify/functions/lead.js
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const nodemailer = require('nodemailer');

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ok:false, error:'Method Not Allowed'}) };
  }
  try {
    const body = JSON.parse(event.body || '{}');
    const { name, phone, serviceSelect, comment, page, time } = body;

    if (!name || !phone) {
      return { statusCode: 400, body: JSON.stringify({ok:false, error:'name/phone required'}) };
    }

    const lines = [
      '🛎 Новая заявка с сайта SanGarant',
      `Имя: ${name}`,
      `Телефон: ${phone}`,
      `Услуга: ${serviceSelect || '—'}`,
      comment ? `Комментарий: ${comment}` : null,
      page ? `Страница: ${page}` : null,
      time ? `Время: ${time}` : null,
    ].filter(Boolean).join('\n');

    const { BOT_TOKEN, CHAT_ID } = process.env;
    let tg = null;
    if (BOT_TOKEN && CHAT_ID) {
      const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
      const r = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ chat_id: CHAT_ID, text: lines })
      });
      tg = await r.json();
    }

    let mail = null;
    if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.MAIL_TO) {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: false,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      });
      mail = await transporter.sendMail({
        from: process.env.MAIL_FROM || process.env.SMTP_USER,
        to: process.env.MAIL_TO,
        subject: 'Заявка с сайта SanGarant',
        text: lines,
      });
    }

    return { statusCode: 200, body: JSON.stringify({ ok:true, tg, mail }) };
  } catch (e) {
    console.error(e);
    return { statusCode: 500, body: JSON.stringify({ ok:false, error: e?.message || 'server error' }) };
  }
};
